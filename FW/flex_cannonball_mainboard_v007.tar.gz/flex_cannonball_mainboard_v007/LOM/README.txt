the firmware update is not required
