DMI updated by the FRU
